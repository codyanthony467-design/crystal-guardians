# Cambios de la tarea

- Se completó la lógica del joystick táctil: detección del área, límite del desplazamiento, zona muerta y liberación de las acciones al soltar.
- Se agregaron controles táctiles visibles para ATACAR y USAR/INTERACTUAR, enlazados con las acciones existentes `player_attack` e `interact`.
- Se instancia `MobileControls` desde `scenes/main.tscn`.
- Se mejoró el HUD de vida añadiendo corazones llenos/vacíos que se actualizan con la vida del jugador.

## Prueba pendiente en dispositivo

Abrir `project.godot` con Godot 4, ejecutar la escena principal y validar el joystick y ambos botones en un dispositivo Android/iOS o en la emulación táctil del editor. La exportación móvil requiere configurar el SDK correspondiente.
